package com.example.Players;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PlayerRepository extends JpaRepository<Player, Integer>{
	
	
	//name list for this query
	
	@Query (value="select * from players where name like ?", nativeQuery=true)
	List<Player> getByname(String name);


	// name is there is any letter
	
	
	@Query(value="select *from players where name like %:name%",nativeQuery=true )
     List<Player> getBylatter(String name);

    @Query(value="select *from players where age>? and age<?",nativeQuery=true)
    
	List<Player> range( int age1 , int age2);
}
 