package com.example.Players;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PlayerController {

	@Autowired
	PlayerServices ps;
	@PostMapping(value="/posting")
	public String post (@RequestBody List<Player> p) {
		return ps.post(p);
		
	}
	
	@PutMapping(value="/putting")
	public String put (@RequestBody  Player p1) {
		return ps.put(p1);
	}
	
	
	@GetMapping(value="/get")
	public List <Player> getting(){
		return ps.getting();
	}
	
	
	@GetMapping(value="/getId/{id}")
	public Player getById(@PathVariable int id) {
		return ps.getById(id);
	}
	
	@DeleteMapping(value="/deleting/{id}")
	public String delete(@PathVariable int id ) {
		return ps.delete(id);
	}
	
	@DeleteMapping(value="/deletAll")
	public String deletes() {
		return ps.deletes();
	}
	
	@GetMapping(value="/gettingName/{name}")
	public List <Player> getByname(@PathVariable String name ){
		return ps.getByname(name);
	}
	@GetMapping(value="/gettingLatter/{latter}")
	public List <Player> getByletter(@PathVariable String name ){
		return ps.getBylatter(name);
	}
	
	@GetMapping(value="rangeFing/{to}")
	public List <Player> range(@PathVariable ("from") int age1,@PathVariable ("to")int age2 ){
		return ps.range (age1,age2);
	}
	
}

