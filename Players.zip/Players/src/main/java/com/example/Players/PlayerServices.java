package com.example.Players;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PlayerServices {
	@Autowired
	PlayerDao pd;
	public String post (List <Player>p) {
		return pd.post(p);
	}
	
	public String put(Player p1) {
		return pd.put(p1);
	}
	
	public List <Player> getting(){
		return pd.getting();
		
	}
	
	public Player getById( int id) {
		return pd.getById(id);
	}
	
	public String delete(int id ) {
		return pd.delete(id);
	}
	
	public String deletes() {
		return pd.deletes();
	
     }
	
	public List <Player> getByname(String name){
		return pd.getByname(name);
	}
	
	public List <Player> getBylatter(String name ){
		return pd.getBylatter(name);
	}
	
	
	public List <Player> range( int age1,int age2 ){
		return pd.range (age1,age2);
	}
 	
	
	
	
	
}
