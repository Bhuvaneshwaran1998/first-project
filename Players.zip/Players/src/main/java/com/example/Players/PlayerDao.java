package com.example.Players;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class PlayerDao {
	
	@Autowired
	PlayerRepository pr;

	public String post(List<Player> p) {
		pr.saveAll(p);
		return "Is Done";
	}
	
	public String put(Player p1) {
		pr.save(p1);
	    return "Is good";
	}
	
	public List<Player> getting(){
		return pr.findAll();
		
	}
	
	
	public Player getById (int id) {
		return pr.findById(id).get();
	}
	
	public String delete(int id ) {
		pr.deleteById(id);
		return "finally delete";
	}
	
	public String deletes() {
		pr.deleteAll();
		return "all of waste of time";
	}

	
	
	public List <Player> getByname(String name){
		return pr.getByname(name);
	}
	
	public List <Player> getBylatter(String name){
		return pr.getBylatter(name);
	}

	public List<Player> range(int age1, int age2) {
		
		
		return pr.range( age1, age2);
	}
	
	
}
